using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace OficiosWeb.Models;

// Las 4 clases son las 4 tablas de la base de datos (mismos nombres de columna que en SQL Server)

[Table("departamento")]
public class Departamento
{
    [Key, Column("id_departamento")] public int IdDepartamento { get; set; }
    [Column("nombre")] public string Nombre { get; set; } = "";
    [Column("activo")] public bool Activo { get; set; } = true;
}

[Table("usuarios")]
public class Usuario
{
    [Key, Column("id_usuario")] public int IdUsuario { get; set; }
    [Column("nombre_completo")] public string NombreCompleto { get; set; } = "";
    [Column("usuario")] public string NombreUsuario { get; set; } = "";
    [Column("contrasena")] public string Contrasena { get; set; } = "";
    [Column("rol")] public string Rol { get; set; } = "";
    [Column("id_departamento")] public int IdDepartamento { get; set; }
    public Departamento? Departamento { get; set; }
}

[Table("solicitudes_oficio")]
public class SolicitudOficio
{
    [Key, Column("id_solicitud")] public int IdSolicitud { get; set; }
    [Column("numero_oficio")] public int NumeroOficio { get; set; }
    [Column("anio")] public int Anio { get; set; }
    [Column("asunto")] public string Asunto { get; set; } = "";
    [Column("fecha_solicitud")] public DateOnly FechaSolicitud { get; set; }
    [Column("hora_solicitud")] public TimeOnly HoraSolicitud { get; set; }
    [Column("estado")] public string Estado { get; set; } = "Asignado";
    [Column("id_usuario")] public int IdUsuario { get; set; }
    [Column("id_departamento")] public int IdDepartamento { get; set; }
    public Usuario? Usuario { get; set; }
    public Departamento? Departamento { get; set; }

    [NotMapped] public string NumeroCompleto => $"{NumeroOficio:0000}/{Anio}";   // ej. 0042/2026
}

[Table("bitacora_cancelacion")]
public class BitacoraCancelacion
{
    [Key, Column("id_bitacora")] public int IdBitacora { get; set; }
    [Column("id_solicitud")] public int IdSolicitud { get; set; }
    [Column("id_usuario")] public int IdUsuario { get; set; }
    [Column("fecha_cancelacion")] public DateOnly FechaCancelacion { get; set; }
    [Column("hora_cancelacion")] public TimeOnly HoraCancelacion { get; set; }
    [Column("motivo")] public string? Motivo { get; set; }
}

// Una fila de la consulta por periodo (no es tabla, solo sirve para mostrar el conteo)
public class FilaPeriodo
{
    public string Departamento { get; set; } = "";
    public int Pendientes { get; set; }
    public int Validados { get; set; }
    public int Cancelados { get; set; }
    public int Total { get; set; }
}
