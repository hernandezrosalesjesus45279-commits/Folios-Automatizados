using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OficiosWeb.Data;
using OficiosWeb.Models;
namespace OficiosWeb.Controllers;

public class PantallasController : Controller
{
    const string Dep = "Secretaria departamental", Dir = "Secretaria del director";
    readonly AppDbContext _db;
    public PantallasController(AppDbContext db) => _db = db;

    // ---------- Ayudas ----------
    // Devuelve al usuario que inició sesión si tiene el rol pedido (si no, null)
    async Task<Usuario?> Quien(string rol)
    {
        var id = HttpContext.Session.GetInt32("uid");
        if (id == null) return null;
        return await _db.Usuarios.Include(u => u.Departamento).FirstOrDefaultAsync(u => u.IdUsuario == id && u.Rol == rol);
    }
    IActionResult ALogin() => RedirectToAction("Login");
    async Task CargarDepartamentos(int? depto, DateOnly? fini, DateOnly? ffin)
    {
        ViewBag.Departamentos = await _db.Departamentos.Where(d => d.Activo).OrderBy(d => d.Nombre).ToListAsync();
        ViewBag.Depto = depto; ViewBag.Fini = fini?.ToString("yyyy-MM-dd"); ViewBag.Ffin = ffin?.ToString("yyyy-MM-dd");
    }
    IQueryable<SolicitudOficio> Todas() => _db.Solicitudes.Include(s => s.Usuario).Include(s => s.Departamento);
    static IQueryable<SolicitudOficio> Filtrar(IQueryable<SolicitudOficio> q, int? depto, string? estado, DateOnly? fini, DateOnly? ffin)
    {
        if (depto != null) q = q.Where(s => s.IdDepartamento == depto.Value);
        if (!string.IsNullOrEmpty(estado)) q = q.Where(s => s.Estado == estado);
        if (fini != null) q = q.Where(s => s.FechaSolicitud >= fini.Value);
        if (ffin != null) q = q.Where(s => s.FechaSolicitud <= ffin.Value);
        return q;
    }

    // ---------- Inicio y cierre de sesión (RF1, RF12) ----------
    public IActionResult Login() => View();

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(string usuario, string contrasena)
    {
        var u = await _db.Usuarios.FirstOrDefaultAsync(x => x.NombreUsuario == usuario && x.Contrasena == contrasena);
        if (u == null) { ViewData["Error"] = "Usuario o contraseña incorrectos"; return View(); }
        HttpContext.Session.SetInt32("uid", u.IdUsuario);
        HttpContext.Session.SetString("nombre", u.NombreCompleto);
        return u.Rol == Dir ? RedirectToAction("RegistroGeneral") : RedirectToAction("SolicitarOficio");
    }
    public IActionResult CerrarSesion() { HttpContext.Session.Clear(); return ALogin(); }

    // ---------- Solicitar número de oficio (RF2, RF3, RF4, RF11) ----------
    public async Task<IActionResult> SolicitarOficio()
    {
        var u = await Quien(Dep); if (u == null) return ALogin();
        return View(u);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SolicitarOficio(string asunto)
    {
        var u = await Quien(Dep); if (u == null) return ALogin();
        asunto = (asunto ?? "").Trim();
        if (asunto.Length == 0 || asunto.Length > 250) { ViewData["Error"] = "El asunto es obligatorio y mide máximo 250 caracteres."; return View(u); }

        // Transacción: dos personas pidiendo a la vez no pueden recibir el mismo número (RNF 3 y 4)
        await using var tx = await _db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);
        int anio = DateTime.Now.Year;   // al cambiar el año, el conteo vuelve a empezar en 1
        int numero = (await _db.Solicitudes.Where(s => s.Anio == anio).MaxAsync(s => (int?)s.NumeroOficio) ?? 0) + 1;
        var nueva = new SolicitudOficio { NumeroOficio = numero, Anio = anio, Asunto = asunto, IdUsuario = u.IdUsuario, IdDepartamento = u.IdDepartamento };
        _db.Solicitudes.Add(nueva);   // fecha, hora y estado "Asignado" los pone SQL Server
        await _db.SaveChangesAsync();
        await tx.CommitAsync();
        return RedirectToAction("OficioAsignado", new { id = nueva.IdSolicitud });
    }

    public async Task<IActionResult> OficioAsignado(int id)
    {
        var u = await Quien(Dep); if (u == null) return ALogin();
        var s = await Todas().FirstOrDefaultAsync(x => x.IdSolicitud == id && x.IdDepartamento == u.IdDepartamento);
        return s == null ? NotFound() : View(s);
    }

    // ---------- Registro general (RF9) ----------
    public async Task<IActionResult> RegistroGeneral(string? buscar, int? depto, string? estado, DateOnly? fini, DateOnly? ffin)
    {
        if (await Quien(Dir) == null) return ALogin();
        var q = Filtrar(Todas(), depto, estado, fini, ffin);
        if (!string.IsNullOrWhiteSpace(buscar))
        {
            int.TryParse(buscar.Split('/')[0], out var n);
            q = q.Where(s => s.Asunto.Contains(buscar) || s.NumeroOficio == n);
        }
        await CargarDepartamentos(depto, fini, ffin);
        ViewBag.Buscar = buscar; ViewBag.Estado = estado;
        return View(await q.OrderByDescending(s => s.IdSolicitud).ToListAsync());
    }

    // ---------- Validar y cancelar (RF6, RF7, RF8) ----------
    public async Task<IActionResult> ValidacionOficio(int id)
    {
        if (await Quien(Dir) == null) return ALogin();
        var s = await Todas().FirstOrDefaultAsync(x => x.IdSolicitud == id);
        return s == null ? NotFound() : View(s);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Validar(int id)
    {
        if (await Quien(Dir) == null) return ALogin();
        var s = await _db.Solicitudes.FindAsync(id);
        if (s != null && s.Estado == "Asignado") { s.Estado = "Validado"; await _db.SaveChangesAsync(); }
        return RedirectToAction("RegistroGeneral");
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancelar(int id, string? motivo)
    {
        var u = await Quien(Dir); if (u == null) return ALogin();
        var s = await _db.Solicitudes.FindAsync(id);
        if (s != null && s.Estado != "Cancelado")
        {
            s.Estado = "Cancelado";   // la fila no se borra, así el número nunca se vuelve a usar
            _db.Bitacora.Add(new BitacoraCancelacion { IdSolicitud = id, IdUsuario = u.IdUsuario, Motivo = motivo });
            await _db.SaveChangesAsync();
        }
        return RedirectToAction("ValidacionOficio", new { id });
    }

    // ---------- Consultas (RF10) ----------
    public async Task<IActionResult> ConsultaDepartamento(int? depto, DateOnly? fini, DateOnly? ffin)
    {
        if (await Quien(Dir) == null) return ALogin();
        await CargarDepartamentos(depto, fini, ffin);
        return View(await Filtrar(Todas(), depto, null, fini, ffin).OrderByDescending(s => s.IdSolicitud).ToListAsync());
    }

    public async Task<IActionResult> ConsultaPeriodo(int? depto, DateOnly? fini, DateOnly? ffin)
    {
        if (await Quien(Dir) == null) return ALogin();
        await CargarDepartamentos(depto, fini, ffin);
        var filas = await Filtrar(_db.Solicitudes, depto, null, fini, ffin)
            .GroupBy(s => s.Departamento!.Nombre)
            .Select(g => new FilaPeriodo
            {
                Departamento = g.Key,
                Pendientes = g.Count(x => x.Estado == "Asignado"),
                Validados = g.Count(x => x.Estado == "Validado"),
                Cancelados = g.Count(x => x.Estado == "Cancelado"),
                Total = g.Count()
            }).ToListAsync();
        return View(filas.OrderBy(f => f.Departamento).ToList());
    }
}
