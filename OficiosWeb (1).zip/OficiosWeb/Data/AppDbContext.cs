using Microsoft.EntityFrameworkCore;
using OficiosWeb.Models;
namespace OficiosWeb.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Departamento> Departamentos => Set<Departamento>();
    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<SolicitudOficio> Solicitudes => Set<SolicitudOficio>();
    public DbSet<BitacoraCancelacion> Bitacora => Set<BitacoraCancelacion>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        // La fecha y la hora las pone el servidor de SQL Server (RNF: hora del servidor)
        mb.Entity<SolicitudOficio>(e =>
        {
            e.Property(x => x.FechaSolicitud).HasDefaultValueSql("CAST(GETDATE() AS DATE)");
            e.Property(x => x.HoraSolicitud).HasDefaultValueSql("CAST(GETDATE() AS TIME(0))");
            e.Property(x => x.Estado).HasDefaultValueSql("'Asignado'");
            e.HasIndex(x => new { x.Anio, x.NumeroOficio }).IsUnique();
        });
        mb.Entity<BitacoraCancelacion>(e =>
        {
            e.Property(x => x.FechaCancelacion).HasDefaultValueSql("CAST(GETDATE() AS DATE)");
            e.Property(x => x.HoraCancelacion).HasDefaultValueSql("CAST(GETDATE() AS TIME(0))");
        });
    }
}
