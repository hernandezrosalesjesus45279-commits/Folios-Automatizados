using Microsoft.EntityFrameworkCore;
using OficiosWeb.Data;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("ConexionOficios")));
// Sesión: recuerda quién inició sesión y se cierra sola a los 15 minutos sin usarse
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(o => { o.IdleTimeout = TimeSpan.FromMinutes(15); o.Cookie.HttpOnly = true; o.Cookie.IsEssential = true; });

var app = builder.Build();
if (!app.Environment.IsDevelopment()) { app.UseExceptionHandler("/Pantallas/Login"); app.UseHsts(); }
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.MapControllerRoute("default", "{controller=Pantallas}/{action=Login}/{id?}");
app.Run();
